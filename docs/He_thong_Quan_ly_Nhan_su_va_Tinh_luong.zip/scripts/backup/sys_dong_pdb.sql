-- TC-55 (SYS, CDB$ROOT): dong PDB truoc khi xoa datafile (gia lap su co mat file)
alter pluggable database freepdb1 close immediate;
