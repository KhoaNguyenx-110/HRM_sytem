-- TC-55 (SYS, CDB$ROOT): thu mo PDB sau khi mat datafile -> mong doi ORA-01157
alter pluggable database freepdb1 open;
select file#, error from v$recover_file;
