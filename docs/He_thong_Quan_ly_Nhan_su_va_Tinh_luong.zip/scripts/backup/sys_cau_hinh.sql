-- =============================================================================
-- TC-55 (SYS, CDB$ROOT): che do ARCHIVELOG va chu ky archive toi da 15 phut
-- (NFR-13 muc tieu thiet ke; archive_lag_target = 900 giay).
-- =============================================================================
set linesize 200
archive log list
alter system set archive_lag_target = 900 scope = both;
select name, value from v$parameter where name in ('archive_lag_target', 'log_archive_dest_1', 'db_recovery_file_dest');
select log_mode, force_logging from v$database;
