-- =============================================================================
-- TC-55 (U_HR01): thay doi SAU ban level 1, COMMIT. Khong co trong ban sao luu nao:
-- chi con trong redo -> sau RECOVER van phai thay (RPO: khong mat giao dich da commit).
-- =============================================================================
set feedback off
begin
  hrm_owner.pkg_hr.sp_cap_nhat_nhan_vien('NV151', p_email => 'nv151.tc55@hrm.example.com');
  commit;
  dbms_output.put_line('Da COMMIT sua email NV151 (sau level 1)');
end;
/
