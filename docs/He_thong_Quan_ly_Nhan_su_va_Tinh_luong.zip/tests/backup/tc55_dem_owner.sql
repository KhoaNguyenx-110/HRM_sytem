-- =============================================================================
-- TC-55 (HRM_OWNER): anh chup de doi chieu truoc su co / sau phuc hoi
--   DEM <bang> <so dong>      cho moi bang cua schema
--   OBJ <loai> <so doi tuong> va INVALID <so doi tuong khong hop le>
--   TIEN tong net va gross cua moi phieu (tong kiem tra so lieu, khong chi so dong)
--   MOC1 / MOC2: hai thay doi sau level 0 va sau level 1 (phai con sau recover)
-- =============================================================================
set feedback off
set linesize 200
declare
  v number;
  v_s varchar2(200);
begin
  for r in (select table_name from user_tables where table_name not like 'DR$%' order by table_name) loop
    execute immediate 'select count(*) from "' || r.table_name || '"' into v;
    dbms_output.put_line('DEM ' || rpad(r.table_name, 24) || v);
  end loop;
  for r in (select object_type, count(*) as so from user_objects group by object_type order by 1) loop
    dbms_output.put_line('OBJ ' || rpad(r.object_type, 24) || r.so);
  end loop;
  select count(*) into v from user_objects where status <> 'VALID';
  dbms_output.put_line('INVALID ' || v);
  select to_char(sum(tong_net), 'FM999999999999990') || ' / ' || to_char(sum(tong_gross), 'FM999999999999990')
    into v_s from phieu_luong;
  dbms_output.put_line('TIEN net/gross ' || v_s);
  select count(*) into v from phat_sinh_luong where can_cu like 'TC-55%';
  dbms_output.put_line('MOC1 phat sinh TC-55 sau level 0: ' || v);
  select nvl(max(email), '-') into v_s from nhan_vien where ma_nhan_vien = 'NV151';
  dbms_output.put_line('MOC2 email NV151 sua sau level 1: ' || v_s);
end;
/
