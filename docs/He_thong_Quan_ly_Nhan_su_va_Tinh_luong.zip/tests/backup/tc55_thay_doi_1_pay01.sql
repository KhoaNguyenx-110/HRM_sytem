-- =============================================================================
-- TC-55 (U_PAY01): thay doi nghiep vu SAU ban level 0, TRUOC ban level 1, COMMIT.
-- Mo ky 04/2026 va lap mot phat sinh thuong -> level 1 phai chua block nay.
-- =============================================================================
set feedback off
declare
  v_ky number;
  v_ps number;
begin
  hrm_owner.pkg_payroll.sp_tao_ky_luong(4, 2026, null, v_ky);
  hrm_owner.pkg_payroll.sp_luu_phat_sinh('NV150', 4, 2026, 'THUONG', 1000000,
    'TC-55 thưởng lập sau bản sao lưu level 0', null, v_ps);
  commit;
  dbms_output.put_line('Da COMMIT ky 04/2026 va phat sinh ' || v_ps);
end;
/
