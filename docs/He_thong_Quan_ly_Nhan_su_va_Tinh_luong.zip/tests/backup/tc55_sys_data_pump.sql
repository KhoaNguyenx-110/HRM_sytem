-- TC-55 (SYS, FREEPDB1): cho HRM_OWNER export schema cua minh vao DATA_PUMP_DIR
grant read, write on directory data_pump_dir to hrm_owner;
set heading off
set feedback off
select 'DIR ' || directory_path from dba_directories where directory_name = 'DATA_PUMP_DIR';
